export enum CommentType {
	PRODUCT = 'product',
	BLOG = 'blog',
}
